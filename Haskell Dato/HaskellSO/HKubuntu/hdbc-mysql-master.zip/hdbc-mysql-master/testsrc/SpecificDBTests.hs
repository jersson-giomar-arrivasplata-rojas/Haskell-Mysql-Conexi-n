module SpecificDBTests where
import Database.HDBC
import Test.HUnit

tests = TestList [] 
                  
